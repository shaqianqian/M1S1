#!/bin/sh
cd ..
make
java -cp bin question6_7.read_fiche

