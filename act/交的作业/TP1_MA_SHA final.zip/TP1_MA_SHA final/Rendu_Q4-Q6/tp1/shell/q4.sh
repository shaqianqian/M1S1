#!/bin/sh
cd ..
make
java -cp bin question4.Question4
