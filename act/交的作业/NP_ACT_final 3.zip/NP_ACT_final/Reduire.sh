#!/bin/sh
#make
java -cp bin JSP.Partition_ins
