#!/bin/sh
cd ..
make
java -cp bin tp2.Game

