package JSP;

public interface Certificat {

	public boolean estCorrect();

	public void suivant();

	public void saisie();
	
	public void alea();
	


}
