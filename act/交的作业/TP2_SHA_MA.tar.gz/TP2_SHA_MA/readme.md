Vous pouvez entrer ficher qu'il s'appelle Shell, et puis foncionne chaque shell
par par exemple sh naive.sh 


cd shell

naive.sh c’est la question 3
dynamique.sh c’est la question 4
sym.sh c’est la question 5 
game.sh c’est le question 10 