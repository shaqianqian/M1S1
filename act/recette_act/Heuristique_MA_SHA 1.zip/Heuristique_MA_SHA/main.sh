#!/bin/sh
make
java -cp bin TP4.Heuristique
