#!/bin/sh
make
java -cp bin JSP.Main
