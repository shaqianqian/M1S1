/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter_ma_sha;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import java.util.List;


/**
 *
 * @author shaqianqian
 */
public class Knn  {

     static int knn_num=5;
      public static void main(String args[]){
    
      ArrayList<String> s1= file_twitter.readFromFiche("contenus_apres_temps.csv");
      ArrayList<String> s2= file_twitter.readFromFiche("twitter_annonce.csv");
      ArrayList<id_direction> distances=annonce(s1.get(0),s2);   
      
     //for(id_direction k:distances){System.out.println(k.i+" "+k.j);}
    int negative=0;
    int positive=0;
    int neutre=0;
        List<id_direction> limits= distances.subList(0, knn_num);
        for(id_direction k:limits){
            if(k.annonce==2){positive++;}
            else if (k.annonce==1){neutre++;}
            else {negative++;}
       
            System.out.println(k.i+" "+k.j+" "+k.annonce);}
           if(positive>negative){
            System.out.println("positive");
           }
           else if (positive<negative)  System.out.println("negative");
           else if (positive==negative) System.out.println("neutre");
      }


      
       private static double distance(String tweet1, String tweet2){
        int nbMotsCommuns = 0, nbMotsTotal = 0;
        String[] mots1 = tweet1.split("\\s+");
        String[] mots2 = tweet2.split("\\s+");
        ArrayList<String> listeMots1 = new ArrayList<>();
        ArrayList<String> same= new ArrayList<>();
        listeMots1.addAll(Arrays.asList(mots1)); // TODO: Etape peut-être pas obligatoire, à revoir
       // TODO: Etape peut-être pas obligatoire, à revoir
          nbMotsTotal=mots1.length+mots2.length;
         for(int j=0;j<mots2.length;j++)
               {
               if(listeMots1.contains(mots2[j]))
             {   
                same.add(mots2[j]);
                listeMots1.remove(mots2[j]);
                
            }
         
         }
          
          nbMotsCommuns=same.size()*2;
          
        
        return (double)(nbMotsTotal - nbMotsCommuns) / (double)nbMotsTotal;
    }
     
      
       private static ArrayList<id_direction> annonce(String s,ArrayList<String> tweets_avec_annonces)
       {   //tweets_avec_annonces= file_twitter.readFromFiche("twitter_annonce.csv");
           ArrayList<String> tweets_sans_annonces=new ArrayList<String> ();
           ArrayList<String> tweets_juste_annonces=new ArrayList<String> ();
           ArrayList<id_direction> knns=new ArrayList<id_direction> ();
           //HashMap<Integer, Double> map = new HashMap<Integer, Double>();
           double[] distances=new double[tweets_avec_annonces.size()];
          for(String i:tweets_avec_annonces){
              tweets_sans_annonces.add(i.substring(0,i.length()-2));
              tweets_juste_annonces.add(i.substring(i.length()-1,i.length()));
             
          }
             for(int j=0;j<tweets_sans_annonces.size();j++){
             double d=distance(s,tweets_sans_annonces.get(j)); 
           
             distances[j]=d;
             knns.add(new id_direction(j,d,Integer.parseInt(tweets_juste_annonces.get(j))));

             
          }
          Collections.sort(knns); 
            
           
           return  knns;
       }
    
       
       
       
       

       
}
