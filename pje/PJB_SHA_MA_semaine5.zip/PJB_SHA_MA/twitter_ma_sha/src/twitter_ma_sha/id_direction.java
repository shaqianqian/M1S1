/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter_ma_sha;

/**
 *
 * @author shaqianqian
 */
public class id_direction implements Comparable {
    public int i;
    public double j;
    public int annonce;
    public id_direction (int i,double j,int annonce){
        this.i=i;
        this.j=j;
        this.annonce=annonce;
    }
    public int getI()
     {
         return i;
     }
     public void setI(int i)
     {
         this.i = i;
     }
      public double getJ()
     {
         return j;
     }
     public void setJ(double j)
     {
         this.j = j;
     }

    @Override
    public int compareTo(Object o) {
 
    
                id_direction b = (id_direction) o;
                
		if((this.j - b.j)<0)return -1;
                else if ((this.j - b.j)==0)return 0;
                else return 1;
  
    }

   
  


}