## AUTHORS:-SHA QIANQIAN-MA LING

## Compt Rendu
-Veuillez trouver en fold ci-joint 'les apprensage de twitter' et en fichier de screen shot par semaine. Cette fold détaile notre parcours d'apprensage par semaine.

-Veuillez trouver en fold twitter_ma_sha. Cette fold est en préparation pour le rendu final du PJB.

## Premier semaine - du 12/09/2017 au 18/09/2017
Dans cette semaine, nous avons appris comment on peut créer un projet avec api twitter. Après l'avoir créer, nous avons créé un test fichier pour tester le api et apprendre comment la fonctionne.
#### Apprendre créer un projet lien à twitter Api
Nous avons essayé de lien le java projet à notre twitter develop projet. D'abord, on a créé un web application. Nous avons suivi un document choinois qui est plus lisible pour nous. Nous avons réalisé les liens par twitter4j.properties.
#### Apprendre twitter Search
Nous avons appris comment usilier le twitter api. Nous avons tester le mot 'boring'. Ce première projet peut affichier tout les tweets contetient 'boring'.
## Seconde semaine - du 19/09/2017/ au 25/09/2017
Cette semaine, notre projet nous a demandé de stockage les twitter de notre recherche. C'est une préparation pour les cours après.
#### Créer fonctions pour stocker les twitter par .txt
Nous avons fini les fonctions pour trirer les messages de user,
#### Créer le tableu pour affichage 
Nous avons diviser les tweets par id,nom,contenu,et date, les afficher sur le tableau.
