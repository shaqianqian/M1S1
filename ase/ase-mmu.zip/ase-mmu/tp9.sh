make
./mi
