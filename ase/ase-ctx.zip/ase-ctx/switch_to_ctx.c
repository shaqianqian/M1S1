#include"ctx.h"

void switch_to_ctx(struct ctx_s *ctx){
	
	if(ctx_courant!=NULL){
	asm (	"movl %%ebp, %0"
		"\n\t"
		"movl %%esp, %1"
		: "=r" (ctx_courant->ebp),
		"=r" (ctx_courant->esp)
	);}
	else{}

	ctx_courant=ctx;
	asm (	"movl %0, %%ebp"
		"\n\t"
		"movl %1, %%esp"
		:: "r" (ctx->ebp),
		"r" (ctx->esp)
	);
	
	if(ctx_courant->etat==INIT){
		ctx_courant->etat=DEMAREE;
		ctx_courant->f(ctx_courant->arg);
		ctx_courant->etat=TERMINE;
		assert(0);	
	}
	else return;
}
