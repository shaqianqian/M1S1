#   Changement de contexte et ordonnancement

Authors: Qianqian SHA , Ling MA

# TP1

Bien fini.

Taper 'sh tp1.sh' pour le tester.

# TP2

Bien fini.

Taper 'sh tp2.sh' pour le test

# TP3
Version1 
utiliser yield pour pingpingpangpang
cd tp3_version1 et sh it

Version2
utiliser horloge pour ping à pong


sh tp3.sh
# TP4

tp4 fini


sh tp4.sh