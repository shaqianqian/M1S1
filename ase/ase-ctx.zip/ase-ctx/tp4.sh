make
./tp4
