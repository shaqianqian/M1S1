#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "hardware.h"
#include "hwconfig.h"

#define N 100 /* nombre de places dans le tampon */


struct sem_s mutex, vide, plein;

typedef int objet_t;

/*un context de objet_t */
struct ctx_obj {
    objet_t  value;
    struct ctx_obj* suivant;
};

struct ctx_pile{
    struct ctx_obj*  top;
    struct ctx_obj*  bas;
};

static struct ctx_pile context;

typedef void (func_t) (void *) ;
enum etat_e {INIT, DEMAREE, TERMINE,BLOQUE} ;

struct ctx_s {
	void* ebp ;
	void* esp ;
	void* arg ;
	func_t* f ;
	enum etat_e etat;
	struct ctx_s* suivant;
	char * stack ;
	struct ctx_s* sem_suivant;
};

struct sem_s{
	int compteur;
	struct ctx_s* ctx_bloque;
};

static struct  ctx_s *curr_ctx =NULL;
static struct  ctx_s *last_ctx =NULL;

int init_ctx (struct ctx_s* ctx, int stack_size, func_t f, void* args);
void switch_to_ctx (struct ctx_s* ctx);
int create_ctx(int stack_size, func_t f, void *args);

void yield();

void sem_init(struct sem_s* sem,unsigned int val);
void sem_up(struct sem_s* sem);
void sem_down(struct sem_s* sem);
