#include"ctx.h"
int init_ctx(struct ctx_s *ctx ,int stack_size,func_t f,void *args){
/*void *ebp,*esp;
 	int magic;
 	char *stack;
	func_t *f;
	void *arg;
	enum etat_e etat;
*/
	ctx->f=f;
	ctx->arg=args;
	ctx->stack=malloc(stack_size);
	assert(ctx->stack!=NULL);
	ctx->esp=ctx->stack+stack_size-sizeof(int);
	ctx->ebp=ctx->esp;
	ctx->etat=INIT;

}
