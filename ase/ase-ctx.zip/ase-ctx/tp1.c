#include <stdio.h>
#include <stdlib.h>

void dipslay_stack()
{  
 void *esp, *ebp;

	asm (	"movl %%esp, %0"
		"\n\t"
		"movl %%ebp, %1"
		: "=r" (esp), "=r" (ebp));

	printf("In display :esp = %p, ebp = %p\n\n", esp, ebp);
}


int main (void)
{
  dipslay_stack();
  return 0; 
}

