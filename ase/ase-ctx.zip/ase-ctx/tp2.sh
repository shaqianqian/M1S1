---------test tp2-----------------------
make
./tp2
make clean
