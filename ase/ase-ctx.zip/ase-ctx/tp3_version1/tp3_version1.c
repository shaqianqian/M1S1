#include "yield_version1.h"

void f_pong(void*);
void f_ping(void*);


int main (void){
	create_ctx(16384, f_ping, NULL);
	create_ctx(16384, f_pong, NULL);
	yield() ;
	exit(EXIT_SUCCESS);
}


void f_ping(void* args){
	while(1){
		printf("A");
		yield();
		printf("B");
		yield();
		printf("C");
		yield();
	}
}

void f_pong(void* args){
	while(1){
		printf("1");
		yield();
		printf("2");
		yield();
	}
}
