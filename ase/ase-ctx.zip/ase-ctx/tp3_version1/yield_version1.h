#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef void (func_t) (void *) ;
enum etat_e {INIT, DEMAREE, TERMINE} ;
struct ctx_s {
	void* ebp ;
	void* esp ;
	void* arg ;
	func_t* f ;
	enum etat_e etat;
	struct ctx_s * suivant;
	char * stack ;
} ;
static struct  ctx_s *curr_ctx =NULL ;
static struct  ctx_s *last_ctx =NULL;

int init_ctx (struct ctx_s* ctx, int stack_size, func_t f, void* args);
void switch_to_ctx (struct ctx_s* ctx);
int create_ctx(int stack_size, func_t f, void *args);

void yield();

