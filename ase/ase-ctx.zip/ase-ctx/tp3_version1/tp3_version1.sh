make
echo "-------------tp3 version1 pingpong avec yield"
./tp3_version1
