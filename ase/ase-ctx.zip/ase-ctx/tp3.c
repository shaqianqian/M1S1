#include "yield.h"

void f_pong(void*);
void f_ping(void*);
void start_schedule();

static void empty_it(void) {
  return;
}

int main (void){
	create_ctx(16384, f_ping, NULL);
	create_ctx(16384, f_pong, NULL);
	start_schedule();
	exit(EXIT_SUCCESS);
}


void f_ping(void* args){
	while(1){
		printf("A");
		printf("B");
		printf("C");
	
	}
}

void f_pong(void* args){
	while(1){
		printf("1");
		printf("2");
	}
}
void start_schedule(){
 unsigned int i;
    
    /* init hardware */
    if (init_hardware(INIFILENAME) == 0) {
	fprintf(stderr, "Error in hardware initialization\n");
	exit(EXIT_FAILURE);
    }
    
    /* dummy interrupt handlers */
    for (i=0; i<16; i++)
	IRQVECTOR[i] = empty_it;

    /* program timer */
    IRQVECTOR[TIMER_IRQ] = yield;    
    _out(TIMER_PARAM,128+64+32+8); /* reset + alarm on + 8 tick / alarm */
    _out(TIMER_ALARM,0xFFFFFFFE);  /* alarm at next tick (at 0xFFFFFFFF) */

   /* allows all IT */
    _mask(1);
    
    /* count for a while... */
    yield();

    /* and exit! */
    exit(EXIT_SUCCESS);
}
