#!/bin/sh

make 
echo "--------test mul------------"

./tp1
./mul 
make clean

