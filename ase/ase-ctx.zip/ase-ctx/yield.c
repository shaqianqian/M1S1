#include "yield.h"

void irq_enable(){
_mask(0);
}
void irq_disable(){
_mask(15);
}
void show() {
  _out(TIMER_PARAM,128+64+32+8);
  _out(TIMER_ALARM,0xFFFFFFFE);
}

int init_ctx (struct ctx_s* ctx, int stack_size, func_t f, void* args){
	ctx->f=f;
	ctx->arg=args;
	ctx->stack=malloc(stack_size);
	assert(ctx->stack!=NULL);
	ctx->esp=ctx->stack+stack_size-sizeof(int);
	ctx->ebp=ctx->esp;
	ctx->etat=INIT;
}

void switch_to_ctx (struct ctx_s* ctx){
	if(curr_ctx!=NULL){
	asm (	"movl %%ebp, %0"
		"\n\t"
		"movl %%esp, %1"
		: "=r" (curr_ctx->ebp),
		"=r" (curr_ctx->esp)
	);}
	else{}

	curr_ctx=ctx;
	asm (	"movl %0, %%ebp"
		"\n\t"
		"movl %1, %%esp"
		:: "r" (ctx->ebp),
		"r" (ctx->esp)
	);
	irq_enable();
	if(curr_ctx->etat==INIT){
		curr_ctx->etat=DEMAREE;
		show();
		curr_ctx->f(curr_ctx->arg);
		irq_disable();		
		curr_ctx->etat=TERMINE;
		yield();
		
	}else if(curr_ctx->etat == DEMAREE) {
		show();
	}
        else{irq_disable();}
	
}

int create_ctx(int stack_size, func_t f, void* args){
        irq_disable();
	struct ctx_s *nouv ;
	nouv = malloc(sizeof(struct ctx_s));
	init_ctx(nouv,stack_size,f,args);
	if(last_ctx==NULL){
		nouv->suivant = nouv;
		last_ctx = nouv ;
	} else {
		nouv->suivant = last_ctx -> suivant ;
		last_ctx->suivant = nouv;
	}
	irq_enable();
}

void yield(void){
	struct ctx_s *tmp;
	if(curr_ctx==NULL){
		assert(last_ctx!=NULL);
		switch_to_ctx(last_ctx);
	}
	else
		{
                    while (curr_ctx->suivant->etat==TERMINE)
                        {
			assert(curr_ctx!=curr_ctx->suivant);
			tmp = curr_ctx->suivant;
                        curr_ctx->suivant=curr_ctx->suivant->suivant;
			free(tmp->stack);
			free(tmp);
                        }
                        last_ctx=curr_ctx;
                        switch_to_ctx(curr_ctx->suivant);
	
               }
}


