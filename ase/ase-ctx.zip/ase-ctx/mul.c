#include <stdio.h>
#include <stdlib.h>
#include "try.h"

static int mul(int depth) {
    int i;

    switch (scanf("%d", &i)) {
        case EOF :
            return 1; 
        case 0 :
            return mul(depth+1);
        case 1 :
            if (i) 
                return i * mul(depth+1);
            else
                return throw(pctx, 0);
    }

	return 0;
}

int main() {
    int product;

	pctx = malloc(sizeof(struct ctx_s));

        printf("Please enter a number -> end by type 'entrée' -> ctrl D for calculate\n");
        printf("A list of int \n");

	product = try(pctx, mul, 0);

        printf("product = %d\n", product);

	free(pctx);

	return 0;
}
