#include <stdio.h>
#include <assert.h>
#include "try.h"

int throw (struct ctx_s *pctx, int r) {

	static int r2 = 0;
        r2 = r;
       
        printf("In throw :esp = %p, ebp = %p\n\n", pctx->esp, pctx->ebp);

	asm (	"movl %0, %%esp"
		"\n\t"
		"movl %1, %%ebp"
		:
		: "r" (pctx->esp), "r" (pctx->ebp));

	return r2;

}
