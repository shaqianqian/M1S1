make
./tp3
