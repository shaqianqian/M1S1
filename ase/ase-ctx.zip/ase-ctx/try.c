#include <stdio.h>
#include <assert.h>
#include "try.h"

int try (struct ctx_s *pctx, func_t *f, int arg) {
      
	asm (	"movl %%esp, %0"
		"\n\t"
		"movl %%ebp, %1"
		: "=r" (pctx->esp), "=r" (pctx->ebp));

	printf("In try :esp = %p, ebp = %p\n\n", pctx->esp, pctx->ebp);
	
	return f(arg);

}


