
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>

enum etat_e{INIT,DEMAREE,TERMINE};

typedef void func_t (void *);

struct ctx_s{
 	void *ebp,*esp;
 	int magic;
 	char *stack;
	func_t *f;
	void *arg;
	enum etat_e etat;
}*ctx;

static struct ctx_s *ctx_courant =NULL;

void switch_to_ctx(struct ctx_s *ctx) ;

int init_ctx(struct ctx_s *ctx, int stack_size,func_t f, void *args);
