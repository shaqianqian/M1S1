#include "sem.h"

void producteur (void*);
void consommateur (void*);
void produire_objet(objet_t * objet);
void retirer_objet(objet_t * objet);
void mettre_objet(objet_t objet);
void utiliser_objet(objet_t  objet);
void start_schedule();

struct ctx_obj* obj;
struct ctx_obj* last;

static void empty_it(void) {
  return;
}


void producteur (void* args)
{
  objet_t objet=0 ;

  while (objet<10) {
    produire_objet(&objet);           /* produire l'objet suivant */
    sem_down(&vide);                  /* dec. nb places libres */
    sem_down(&mutex);                 /* entree en section critique */
    mettre_objet(objet);              /* mettre l'objet dans le tampon */
    sem_up(&mutex);                   /* sortie de section critique */
    sem_up(&plein);                   /* inc. nb place occupees */
  }
}

void consommateur (void* args)
{
  objet_t objet ;

  while (1) {
    sem_down(&plein);                 /* dec. nb emplacements occupes */
    sem_down(&mutex);                 /* entree section critique */
    retirer_objet (&objet);           /* retire un objet du tampon */
    sem_up(&mutex);                   /* sortie de la section critique */
    sem_up(&vide);                    /* inc. nb emplacements libres */
    utiliser_objet(objet);            /* utiliser l'objet */
  }

}

void produire_objet(objet_t* objet) {
        (*objet)++;
	printf("produire_objet:%i\n", *objet);
}

void utiliser_objet(objet_t objet) {
         printf("utiliser_objet: %i\n", objet);
}


void mettre_objet(objet_t objet) {
	obj = malloc(sizeof(struct ctx_obj));
	obj->suivant = NULL;	
	obj->value=objet;
	if(context.top != NULL) {
		context.bas->suivant= obj;
		context.bas = obj;
	}
	else{   context.bas = obj;
		context.top = context.bas ;}
	printf("mettre_objet: %i\n", objet);
}

void retirer_objet(objet_t* objet) {
	while(context.top!= NULL) {
		*objet = context.top->value;
		last = context.top;
		context.top = context.top->suivant;
	}
	printf("retirer_objet: %i\n", *objet);	
}

void start_schedule() 
{
	
    unsigned int i;
    
    /* init hardware */
    if (init_hardware(INIFILENAME) == 0) {
        printf("Error in hardware initialization\n");
        exit(EXIT_FAILURE);
    }
    
    /* dummy interrupt handlers */
    for (i=0; i<16; i++)
        IRQVECTOR[i] = empty_it;
    
    /* program timer */
    IRQVECTOR[TIMER_IRQ] = yield;
    _out(TIMER_PARAM,128+64+32+1); /* reset + alarm on + 1 tick / alarm */
    _out(TIMER_ALARM,0xFFFFFFFE);  /* alarm at next tick (at 0xFFFFFFFF) */
    
    /* allows all IT */
    _mask(1);
    
    /* count for a while... */
     yield();
    /* and exit! */
    exit(0);
    

}
int main(int argc, char *argv[])
{
	context.top=NULL;
	context.bas=NULL;
	sem_init(&mutex, 1);                
	sem_init(&vide, N);                
	sem_init(&plein, 0); 
	create_ctx(1638400, producteur, NULL);              
	create_ctx(1638400, consommateur, NULL);
        start_schedule();
    
    return 0;
}


