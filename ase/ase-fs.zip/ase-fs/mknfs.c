
#include "vol.h"
#include "mbr.h"
#include "drive.h"

int main(int argc, char ** argv){
	
	char *current_vol_str = getenv("CURRENT_VOLUME");

	assert(current_vol_str!= NULL);
	current_vol = atoi(current_vol_str);

	unsigned int serial;
	
	if(argc != 3) {
		fprintf(stderr, "Usage : ./mknfs  <name> <serial>\n");
		exit(EXIT_FAILURE);
	}

	initialize();
	
	load_mbr();

	serial=atoi(argv[2]);

	assert(current_vol>= 0 && current_vol <=8);

	init_super(current_vol,argv[1],serial);

	exit(EXIT_SUCCESS);
}
