#include "mbr.h"
#include "drive.h"

int newvolume(unsigned int cyl, unsigned int sec, unsigned int size,unsigned int type){
	unsigned int i = 0;
	unsigned char buffer[HDA_SECTORSIZE];
	while ((i < 8) && (mbr.vols[i].valid)) {
		i++;
	}

	mbr.vols[i].premier_cylindre = cyl;
	
	mbr.vols[i].premier_secteur =sec;
	
	mbr.vols[i].nb_blocs =size;	
	
	switch((int)type){
	case 0:
		mbr.vols[i].type=BASE;
		break;
	case 1:
		mbr.vols[i].type=ANNEXE;
		break;
	case 2:
		mbr.vols[i].type=AUTRE;
		break;
	default:
		break;
	}
	mbr.vols[i].valid = 1;
	
	mbr.nb_vols++;

	save_mbr();
	return 1;
}
void init_mbr() {
	memset(&mbr, 0, sizeof(struct mbr_s));
	mbr.magic = MBRMAGIC;
}

void load_mbr() {
	unsigned char buf[HDA_SECTORSIZE];
	read_sector(0, 0, buf);
	memcpy(&mbr, buf, sizeof(struct mbr_s));
	if(mbr.magic != MBRMAGIC){
		init_mbr();
		save_mbr();	
	}
}

void save_mbr() {
	unsigned char buf[HDA_SECTORSIZE];
	memset(buf, 0, HDA_SECTORSIZE);
	memcpy(buf, &mbr, sizeof(struct mbr_s));
	write_sector(0, 0, buf);
}

unsigned int cylinder_de_bloc(unsigned int vol,unsigned int nbloc){
	return mbr.vols[vol].premier_cylindre + (mbr.vols[vol].premier_secteur + nbloc) /HDA_MAXSECTOR;
}
unsigned int sector_de_bloc(unsigned int vol,unsigned int nbloc){
	return (mbr.vols[vol].premier_secteur + nbloc) % HDA_MAXSECTOR;
}

void read_bloc(unsigned int vol, unsigned int nbloc, unsigned char *buffer) {
	read_sector(cylinder_de_bloc(vol, nbloc),sector_de_bloc(vol, nbloc) , buffer);
}

void write_bloc(unsigned int vol, unsigned int nbloc, const unsigned char *buffer) {
	write_sector(cylinder_de_bloc(vol, nbloc),sector_de_bloc(vol, nbloc), buffer);
}

void format_vol(unsigned int vol) {
	unsigned int cyl = mbr.vols[vol].premier_cylindre;
	unsigned int first_sect = mbr.vols[vol].premier_secteur;
	unsigned int nbsec = sector_de_bloc(vol, mbr.vols[vol].nb_blocs);
	format_sector(cyl, first_sect, nbsec, 0);
}
