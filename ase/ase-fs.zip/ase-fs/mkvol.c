
#include "drive.h"
#include "mbr.h"

int main(int argc, char *argv[]) {
	
	unsigned int i = 0;
	unsigned char buffer[HDA_SECTORSIZE];

	initialize();
	if(argc != 5) {
		fprintf(stderr, "Usage : ./mkvol <Cylinder> <Sector> <nbBlocs> <Type(BASE:0 ANNEXE:1 AUTRE:2) >\n");
		exit(EXIT_FAILURE);
	}

	load_mbr();
		
	while ((i < 8) && (mbr.vols[i].valid)) {
		i++;
	}

	mbr.vols[i].premier_cylindre = atoi(argv[1]);
	
	mbr.vols[i].premier_secteur =atoi(argv[2]);
	
	mbr.vols[i].nb_blocs = atoi(argv[3]);	
	
	switch((int)atoi(argv[4])){
	case 0:
		mbr.vols[i].type=BASE;
		break;
	case 1:
		mbr.vols[i].type=ANNEXE;
		break;
	case 2:
		mbr.vols[i].type=AUTRE;
		break;
	default:
		break;
	}
	mbr.vols[i].valid = 1;
	
	mbr.nb_vols++;

	save_mbr();
	
	printf("Made Vol N°%d Success!\n",i);

	exit(EXIT_SUCCESS);
}
