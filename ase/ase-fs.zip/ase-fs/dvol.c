#include "mbr.h"
#include "drive.h"

int main() {
	initialize();
	load_mbr();
	
	if (mbr.nb_vols == 0)
		printf("There is no volume, please make volume first and then display\n");
	else {
		assert(mbr.magic == MBRMAGIC);
		for (int i = 0; i <8; i++) {
			if (mbr.vols[i].valid){
				switch(mbr.vols[i].type){
					case BASE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: BASE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);
						break;
					case ANNEXE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: ANNEXE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);break;
					
					case AUTRE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: AUTRE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);break;

					default:break;
				}		

			}
		}
	
	}
	
	exit(EXIT_SUCCESS);
}
