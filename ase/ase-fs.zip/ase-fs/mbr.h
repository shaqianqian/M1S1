#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "hardware.h"
#include "constant.h" 

struct mbr_s mbr;
enum vol_type_e {BASE, ANNEXE, AUTRE,FREE};

struct vol_s {
	unsigned int premier_cylindre;
	unsigned int premier_secteur;
	unsigned int nb_blocs;
	enum vol_type_e type;
	int valid;
};

struct mbr_s {
	unsigned int nb_vols;
	struct vol_s vols[8];
	int magic;
};

void init_mbr();
void load_mbr();
void save_mbr();

void init_vol(unsigned int cylinder,unsigned int sector,unsigned int size,unsigned int type);
void read_bloc(unsigned int numVol, unsigned int numBloc, unsigned char *buffer);
void write_bloc(unsigned int numVol, unsigned int numBloc, const unsigned char *buffer);
void format_vol(unsigned int numVol);
unsigned int cylinder_de_bloc(unsigned int vol,unsigned int nbloc);
unsigned int sector_de_bloc(unsigned int vol,unsigned int nbloc);
int newvolume(unsigned int cyl, unsigned int sec, unsigned int size,unsigned int type);
