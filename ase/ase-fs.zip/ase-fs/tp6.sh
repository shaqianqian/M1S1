echo "----------make mkvol dvol shvol--------------------------"
make
echo "----------tester mkvol---------------------------"
./mkvol 1 2 3 BASE
./mkvol 4 5 6 ANNEXE
echo "----------tester dvol---------------------------"
./dvol

