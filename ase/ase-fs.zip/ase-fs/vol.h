#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "hardware.h"
#include "constant.h" 

struct superbloc_s {
    unsigned int magic;
    unsigned int serial;
    unsigned char name[32];
    int racine;
    unsigned int premier_bloc_libre;
    unsigned int nbBlocsLibres;
};

struct superbloc_s super;
unsigned int current_vol;

struct bl_s {
	unsigned int magic;
	unsigned int suivant;
};

void init_super(unsigned int vol,const char* name,unsigned int serial);
int load_super(unsigned int vol);
void save_super();
unsigned int new_bloc();
void free_bloc(unsigned int bloc);
void free_blocs(unsigned int *blocs, unsigned int nbBlocs);

