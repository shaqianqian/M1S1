FILENAME="haha.txt"
echo "----------Test inode--------------------------"
make
echo "----------create 3 vols--------------------------------------"
./mkvol 1 2 9 2
./mkvol 5 7 13 1
./mkvol 2 3 11 0
echo "----------display mbr status---------------------------------"
./dvol
echo "----------add name and serial to the vol existed-------------"
echo "----------use CURRENT_VOLUME to inialize--------------------"
export CURRENT_VOLUME=0
./mknfs "VOLUME_0" 123
./dfs
export CURRENT_VOLUME=1
./mknfs "VOLUME_1" 456
./dfs
export CURRENT_VOLUME=2
./mknfs "VOLUME_2" 789
echo "----------display volume with their name and serial--------- "
./dfs
echo "----------create a new file in CURRENT_VOLUME--------------------- "
export CURRENT_VOLUME=1
echo "----------type some word here and end with enter+ctrl+d----------- "
echo "----------remembre you fd number-----------------------------"
cat $FILENAME|./if_nfile
echo "----------show status----------------------------------------"
./dfs
echo "----------print that you have written ---------------------- "
./if_pfile 1 
echo "----------copy that you have written ----------------------- "
./if_cfile 1 > file_copied_1.txt
echo "----------print that you have copied ----------------------- "
./if_pfile 3
echo "----------show status----------------------------------------"
./dfs
echo "----------delete that you have copied------------------------"
./if_dfile 3
echo "----------show status----------------------------------------"
./dfs
