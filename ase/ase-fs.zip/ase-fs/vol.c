#include "constant.h"
#include "drive.h"
#include "mbr.h"
#include "vol.h"

void init_super(unsigned int vol,const char* name,unsigned int serial){
	unsigned int i;
	struct bl_s blocLibre;
	unsigned char buff[HDA_SECTORSIZE];

	assert(vol < mbr.nb_vols);
	current_vol = vol;
	super.magic = SUPERMAGIC;
	super.serial = serial;
	strncpy(super.name, name, 32);
	super.name[31] = '\0';
	super.racine = 1;
	super.premier_bloc_libre = 1;
	super.nbBlocsLibres = mbr.vols[vol].nb_blocs - 1;
	save_super();
	printf("Vol N°%d is already initialized \n",vol);
	assert(sizeof(struct bl_s) <= HDA_SECTORSIZE);
	memset(buff, 0, HDA_SECTORSIZE);
	for(i = 1; i < mbr.vols[vol].nb_blocs; i++) {
		blocLibre.magic = BLOCMAGIC;
		blocLibre.suivant = (i == mbr.vols[vol].nb_blocs - 1) ? 0 : i+1;
		memcpy(buff, &blocLibre, sizeof(struct bl_s));
		write_bloc(vol, i, buff);
	}
}


int load_super(unsigned int vol){	

	unsigned char buff[HDA_SECTORSIZE];
	memset(buff, 0, HDA_SECTORSIZE);
	read_bloc(vol, 0, buff);
	memcpy(&super, buff, sizeof(struct superbloc_s));
	if (super.magic == SUPERMAGIC)
		return 0;
	return -1;
}

void save_super(){	
	unsigned char buff[HDA_SECTORSIZE];
	memset(buff, 0, HDA_SECTORSIZE);
	memcpy(buff, &super, sizeof(struct superbloc_s));
	write_bloc(current_vol, 0, buff);
}

void read_bloc_libre(unsigned int numBloc, struct bl_s *blocLibre) {

	unsigned char buff[HDA_SECTORSIZE];
	read_bloc(current_vol, numBloc, buff);
	memcpy(blocLibre, buff, sizeof(struct bl_s));
	assert(blocLibre->magic == BLOCMAGIC);

}

unsigned int new_bloc(){
	
	struct bl_s bl;
	unsigned int nbloc = super.premier_bloc_libre;
	if(nbloc != 0) {
		read_bloc_libre(nbloc, &bl);
		super.nbBlocsLibres--;
		super.premier_bloc_libre = bl.suivant;
		save_super();
	}
	return nbloc;
}
void free_blocs(unsigned int *blocs, unsigned int nbBlocs) {

	unsigned int i;
	for(i = 0; i < nbBlocs; i++) {
		if(blocs[i] != 0)
			free_bloc(blocs[i]);
	}

}
void free_bloc(unsigned int n) {
	unsigned char buff[HDA_SECTORSIZE];
	struct bl_s blocLibre;
	assert(n < mbr.vols[current_vol].nb_blocs - 1);
	blocLibre.magic = BLOCMAGIC;
	blocLibre.suivant = super.premier_bloc_libre;
	super.premier_bloc_libre = n;
	super.nbBlocsLibres++;
	memset(buff, 0, 256);
	assert(sizeof(struct bl_s) <= HDA_SECTORSIZE);
	memcpy(buff, &blocLibre, sizeof(struct bl_s));
	write_bloc(current_vol, n, buff);
	save_super();

}

/*
void free_bloc(unsigned int bloc){
		
	unsigned char buffer[HDA_SECTORSIZE];
	struct bl_s free_bloc;
	free_bloc.suivant = super.premier_bloc_libre;
	printf("free_bloc\n");
	memset(buffer, 0, HDA_SECTORSIZE);
	memcpy(buffer, &free_bloc, sizeof(struct bl_s));
	write_bloc(current_vol, bloc, buffer);
	super.premier_bloc_libre = bloc;
	super.nbBlocsLibres++;
	save_super();
	printf("free_bloc_success: end\n");
}*/
