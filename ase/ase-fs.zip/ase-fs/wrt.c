#include "drive.h"

int main (int argc, char ** argv) {
	
	const unsigned char buffer[]="0xAB";
	unsigned int i=atoi(argv[1]);
	unsigned int j=atoi(argv[2]);
	if(argc !=3){
		printf("input: cylindre and secteur en hexa");
		exit(EXIT_FAILURE);
	}
	initialize();
	write_sector(i,j,buffer);
	exit(EXIT_SUCCESS);
}
