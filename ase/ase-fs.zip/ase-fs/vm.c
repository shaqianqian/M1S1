#include "mbr.h"
#include "constant.h"
#include "drive.h"

/* ------------------------------
   command list
   ------------------------------------------------------------*/
struct _cmd {
    char *name;
    void (*fun) (struct _cmd *c);
    char *comment;
};

static void list(struct _cmd *c);
static void new(struct _cmd *c);
static void del(struct _cmd *c);
static void help(struct _cmd *c) ;
static void save(struct _cmd *c);
static void quit(struct _cmd *c);
static void xit(struct _cmd *c);
static void none(struct _cmd *c) ;

static struct _cmd commands [] = {
    {"list", list, 	"display the partition table"},
    {"new",  new,	"create a new partition"},
    {"del",  del,	"delete a partition"},
    {"save", save,	"save the MBR"},
    {"quit", quit,	"save the MBR and quit"},
    {"exit", xit,	"exit (without saving)"},
    {"help", help,	"display this help"},
    {0, none, 		"unknown command, try help"}
} ;

/* ------------------------------
   dialog and execute 
   ------------------------------------------------------------*/
static void
execute(const char *name)
{
    struct _cmd *c = commands; 
  
    while (c->name && strcmp (name, c->name))
	c++;
    (*c->fun)(c);
}

static void
loop(void)
{
    char name[64];
    
    while (printf("> "), scanf("%62s", name) == 1)
	execute(name) ;
}

/* ------------------------------
   command execution 
   ------------------------------------------------------------*/
static void
list(struct _cmd *c)
{
   if (mbr.nb_vols == 0)
		printf("There is no volume, please make volume first and then display\n");
	else {
		assert(mbr.magic == MBRMAGIC);
		for (int i = 0; i <8; i++) {
			if (mbr.vols[i].valid){
				switch(mbr.vols[i].type){
					case BASE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: BASE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);
						break;
					case ANNEXE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: ANNEXE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);break;
					
					case AUTRE:
						printf("Vol N°%d : <Cyliner: %d > <Sector: %d > <Blocs: %d > <Type: AUTRE> \n", i, mbr.vols[i].premier_cylindre, mbr.vols[i].premier_secteur, mbr.vols[i].nb_blocs);break;

					default:break;
				}		

			}
		}
	
	}
}

static void
new(struct _cmd *c)
{
  int cyl,sec,size,type;
	printf("%s \n", c->name);
	printf("Enter Cylindre : \n");
	scanf ("%i",&cyl);
	printf("Enter Secteur : \n");
	scanf ("%i",&sec);
	printf("Enter Size : \n");
	scanf ("%i",&size);
	printf("Enter Type \n (0: BASE, 1: ANNEXE, 2 TYPE): \n");
	scanf ("%i",&type);
	if(newvolume(cyl,sec,size,type)==1)
		printf("new volume success\n");
	else
		printf("new volume fail\n");
}

static void
del(struct _cmd *c)
{
    int vol, i;
    printf("Enter the Vol Number to delete: ");
    scanf("%d", &vol);
    if (vol>= mbr.nb_vols) {
        printf("Number invalide, try again please\n");
        return;
    }
    
    for (i = vol; i < mbr.nb_vols - 1; i++) {
        mbr.vols[i] = mbr.vols[i + 1];
    }
    mbr.nb_vols--;
    save_mbr();
    printf("del success\n");
}

static void
save(struct _cmd *c)
{
    save_mbr();
}

static void
quit(struct _cmd *c)
{
    printf("%s BYE_BYE (>.<)\n", c->name); 
    exit(EXIT_SUCCESS);
}

static void
do_xit()
{
    exit(EXIT_SUCCESS);
}

static void
xit(struct _cmd *dummy)
{
    do_xit(); 
}

static void
help(struct _cmd *dummy)
{
    struct _cmd *c = commands;
  
    for (; c->name; c++) 
	printf ("%s\t-- %s\n", c->name, c->comment);
}

static void
none(struct _cmd *c)
{
    printf ("%s\n", c->comment) ;
}

int
main(int argc, char **argv)
{
    initialize();
    load_mbr();
    /* dialog with user */ 
    loop();

    /* abnormal end of dialog (cause EOF for xample) */
    do_xit();

    /* make gcc -W happy */
    exit(EXIT_SUCCESS);
}
