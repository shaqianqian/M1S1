
#include "mbr.h"
#include "vol.h"
#include "drive.h"
#include "inode.h"

unsigned initialize_bloc(unsigned nbloc) {
	int bloc[NBPB];
	int i;
	read_bloc(current_vol, nbloc, (unsigned char*) &bloc);
	for (i = 0; i < NBPB; i++) {
		bloc[i] = 0;
	}
	write_bloc(current_vol, nbloc, (unsigned char*) &bloc);
	return nbloc;
}

void read_inode(unsigned int inumber, struct inode_s* inode) {
	unsigned char buffer[HDA_SECTORSIZE];
	read_bloc(current_vol, inumber, buffer);
	memcpy(inode, buffer, sizeof(struct inode_s));
}

void write_inode(unsigned int inumber, const struct inode_s *inode) {
	unsigned char buffer[HDA_SECTORSIZE];
	memcpy(buffer, inode, sizeof(struct inode_s));
	write_bloc(current_vol, inumber, buffer);
}

unsigned int create_inode(enum file_type_e type) {
	struct inode_s inode;
	unsigned int inumber = new_bloc();
	if(inumber != 0) {
		memset(&inode, 0, sizeof(struct inode_s));
		inode.type = type;
		write_inode(inumber, &inode);
	}

	return inumber;

}
int delete_indirect(unsigned int indirect){
		unsigned int *tab_ind=malloc(N_DIRECT);
		read_bloc(current_vol, indirect, (unsigned char*)tab_ind);
		free_blocs(tab_ind,N_DIRECT);
		free(tab_ind);
}
int delete_d_indirect(unsigned int d_indirect){
		unsigned int tab_db[N_DIRECT];
		read_bloc(current_vol, d_indirect,(unsigned char* )tab_db);
		for(unsigned int i = 0; i < N_DIRECT; i++) {
			if(tab_db[i] != 0) {
				delete_indirect(d_indirect);
			}
		}
		free_bloc(d_indirect);
}
int delete_inode(unsigned int inumber) {

	struct inode_s inode;
	read_inode(inumber, &inode);
	free_blocs(inode.direct, N_DIRECT);
	if(inode.indirect!=BLOC_NULL) {
		delete_indirect(inode.indirect);
	}
	if(inode.d_indirect!= BLOC_NULL) {
		delete_d_indirect(inode.d_indirect);
	}
	free_bloc(inumber);
	printf("Delete ifile fd=%d success\n!",inumber);
	return 0;

}

unsigned int vbloc_of_fbloc(unsigned int inumber, unsigned int fbloc,bool_t do_allocate) {

	unsigned int bloc[NBPB],nbloc;
	struct inode_s inode;
	read_inode(inumber, &inode);

	if (fbloc < N_DIRECT) {
	 if (inode.direct[fbloc] == 0) {
	  if (do_allocate) {
		nbloc = new_bloc();
		inode.direct[fbloc] = initialize_bloc(nbloc);
		write_inode(inumber, &inode);
	  } 		
	  return BLOC_NULL;
	
	 }
	 return (inode.direct[fbloc]);
        }

	fbloc -= N_DIRECT;
	if (fbloc < NBPB) {
		if (inode.indirect == 0){
			if (do_allocate) {
				nbloc = new_bloc();
				inode.indirect = initialize_bloc(nbloc);
				write_inode(inumber, &inode);
			} 
			return BLOC_NULL;
		}
		read_bloc(current_vol, inode.indirect, (unsigned char*) &bloc);

		if (bloc[fbloc] == 0) {
			if (do_allocate) {
				nbloc = new_bloc();
				bloc[fbloc] = initialize_bloc(nbloc);
				write_bloc(current_vol, inode.indirect, (unsigned char*) &bloc);
				write_inode(inumber, &inode);
			}
			return BLOC_NULL;
		}
		return bloc[fbloc];
	}
	
	fbloc -= NBPB;
	
	if (fbloc < (NBPB * NBPB)) {
		if (inode.d_indirect == 0) {
			if (do_allocate) {
				nbloc = new_bloc();
				inode.d_indirect = initialize_bloc(nbloc);
				write_inode(inumber, &inode);
			} 
			return BLOC_NULL;
		}
		unsigned int bloc2[NBPB];
		read_bloc(current_vol, inode.d_indirect, (unsigned char*) &bloc);
		if (bloc[fbloc / NBPB] == 0) {
			if (do_allocate) {
				nbloc = new_bloc();
				bloc[fbloc / NBPB] = initialize_bloc(nbloc);
				write_bloc(current_vol, inode.d_indirect,(unsigned char*) &bloc);
			} 
			return BLOC_NULL;
		}
		return BLOC_NULL;
	}

}

