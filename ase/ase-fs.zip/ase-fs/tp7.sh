echo "----------make mknfs dfs dvol mkvol--------------------------"
make
echo "----------create 3 vols--------------------------------------"
./mkvol 1 2 3 0
./mkvol 4 5 6 1
./mkvol 2 3 4 2
echo "----------display mbr status---------------------------------"
./dvol
echo "----------add name and serial to the vol existed-------------"
echo "----------use CURRENT_VOLUME to inialize--------------------"
export CURRENT_VOLUME=0
./mknfs "VOLUME_0" 123
./dfs
export CURRENT_VOLUME=1
./mknfs "VOLUME_1" 456
./dfs
export CURRENT_VOLUME=2
./mknfs "VOLUME_2" 789
echo "----------display volume with their name and serial--------- "
./dfs
