#ifndef _INODE_H_
#define _INODE_H_
#include "constant.h"
#include "tools.h"
 
enum file_type_e {FILE_FILE, FILE_DIRECTORY, FILE_SPECIAL};

struct inode_s {
    	enum file_type_e type;
        unsigned int ind_size;      /* in octets */
    	unsigned int direct[N_DIRECT];
    	unsigned int indirect;
    	unsigned int d_indirect;
};

#define BLOC_NULL 0

void read_inode(unsigned int inumber, struct inode_s* inode);
void write_inode(unsigned int inumber, const struct inode_s *inode);
unsigned int initialize_bloc(unsigned int bloc);
unsigned int create_inode(enum file_type_e type); 
int delete_inode(unsigned int inumber);
unsigned int vbloc_of_fbloc(unsigned int inumber, unsigned int fbloc,bool_t do_allocate); 

#endif
