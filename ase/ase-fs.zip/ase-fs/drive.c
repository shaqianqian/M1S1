#include "drive.h"
#include "constant.h"

void seek (unsigned int cylinder, unsigned int sector) {
	_out(HDA_DATAREGS, (cylinder >> 8) & 0xFF);
	_out(HDA_DATAREGS + 1, (cylinder) & 0xFF);
	_out(HDA_DATAREGS + 2, (sector >> 8) & 0xFF);
	_out(HDA_DATAREGS + 3, (sector) & 0xFF);
	_out(HDA_CMDREG,CMD_SEEK);
	return;
}

void read_sector(unsigned int cylinder, unsigned int sector, unsigned char *buffer) {
	seek(cylinder, sector);
	_sleep(HDA_IRQ);
	_out(HDA_DATAREGS, 0);
	_out(HDA_DATAREGS + 1, 1);
	_out(HDA_CMDREG,CMD_READ);
	_sleep(HDA_IRQ);
	for (int i=0; i<HDA_SECTORSIZE ;i++) 
		buffer[i]=MASTERBUFFER[i];
	return;
}

void write_sector(unsigned int cylinder, unsigned int sector, const unsigned char *buffer) {
	seek(cylinder, sector);
	_sleep(HDA_IRQ);
	for (int i=0; i<HDA_SECTORSIZE ; i++) {
		MASTERBUFFER[i] = buffer[i];
	}
	_out(HDA_DATAREGS,0);
	_out(HDA_DATAREGS + 1,1);
	_out(HDA_CMDREG, CMD_WRITE);
	_sleep(HDA_IRQ);
	return;
}

void format_sector(unsigned int cylinder, unsigned int sector, unsigned int nsector,  unsigned int value) {
	seek(cylinder, sector);
	_sleep(HDA_IRQ);
	_out(HDA_DATAREGS, (nsector >> 8) & 0xFF);
	_out(HDA_DATAREGS + 1, nsector & 0xFF);
	_out(HDA_DATAREGS + 2, (value >> 24) & 0xFF);
	_out(HDA_DATAREGS + 3, (value >> 16) & 0xFF);
	_out(HDA_DATAREGS + 4, (value >> 8) & 0xFF);
	_out(HDA_DATAREGS + 5, (value) & 0xFF);
	_out(HDA_CMDREG, CMD_FORMAT);
	for (int i = 0; i < nsector; i++)
		_sleep(HDA_IRQ);
	return;
}
static void empty_it(){
	return;
}


void initialize(){
    unsigned int i;
	/* init hardware */
    if(init_hardware("hwconfig.ini") == 0) {
	fprintf(stderr, "Error in hardware initialization\n");
	exit(EXIT_FAILURE);
    }

    /* Interreupt handlers */
    for(i=0; i<16; i++)
	IRQVECTOR[i] = empty_it;

    /* Allows all IT */
    _mask(1);
}
