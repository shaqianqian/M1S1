make
./vm
