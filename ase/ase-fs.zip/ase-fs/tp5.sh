echo "----------make dmps frmt wrt--------------------------"
make
echo "----------tester dmps_sector---------------------------"
./dmps 0x01 0x02
echo "-----------tester frmt_sector--------------------------"
./frmt
./dmps 0x01 0x02
echo "-----------tester wrt_sector---------------------------"
./wrt 0x01 0x02
./dmps 0x01 0x02
echo "-----------fin tp5------------------------------------"
make clean
