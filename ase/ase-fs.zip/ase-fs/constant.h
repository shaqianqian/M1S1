
#define HDA_CMDREG       0x3F6       
#define HDA_DATAREGS     0x110       
#define HDA_IRQ          14          
#define HDA_MAXCYLINDER  16          
#define HDA_MAXSECTOR    16           
#define HDA_SECTORSIZE   256

#define MBRMAGIC 59650
#define BLOCMAGIC 59651
#define SUPERMAGIC 59652

#define N_DIRECT HDA_SECTORSIZE/4-4
#define N_DIRECT2 		1
#define NBPB            (HDA_SECTORSIZE/sizeof(unsigned int))
#define BLOC_SIZE   HDA_SECTORSIZE
#define DATA_BLOC_SIZE  BLOC_SIZE

