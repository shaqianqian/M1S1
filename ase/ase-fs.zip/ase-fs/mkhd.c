
#include "drive.h"

int
main(int argc, char **argv)
{
    initialize();
    /* and exit! */
    exit(EXIT_SUCCESS);
}
