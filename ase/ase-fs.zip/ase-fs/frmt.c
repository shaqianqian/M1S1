#include"drive.h"

int main (int argc, char ** argv) {	
	if(argc !=1){
		printf("format make the disque tous 0");
		exit(EXIT_FAILURE);
	}
	printf("please wait a little bit\n");
	initialize();
	for (int j = 0; j < HDA_MAXCYLINDER; j++)
		format_sector(j, 0, HDA_MAXSECTOR, 0);
	printf("success\n");
	exit(EXIT_SUCCESS);
}
