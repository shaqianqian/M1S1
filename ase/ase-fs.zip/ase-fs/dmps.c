#include"drive.h"

int main (int argc, char ** argv) {
	int i;
	unsigned int cylinder, sector;
	unsigned char buffer[HDA_SECTORSIZE];
	
	if(argc !=3){
		printf("iput cylindre and secteur en hexa\n");
		exit(EXIT_FAILURE);
	}

	cylinder = atoi(argv[1]);
	sector = atoi(argv[2]);
	initialize();
	read_sector(cylinder,sector,buffer);
	for (int i = 0; i< HDA_MAXCYLINDER; i++) {
		for(int j=0;j<HDA_MAXSECTOR;j++)
			printf("%02x ",buffer[i*16+j]);
			printf("\n");
	}  
	exit(EXIT_SUCCESS);
}
