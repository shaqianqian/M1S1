#include "drive.h"
#include "mbr.h"
#include "vol.h"

int main() {

	unsigned int i,j;
	initialize();
	load_mbr();
	char* current_volume_str;
        current_volume_str = getenv("CURRENT_VOLUME");
	current_vol = strtol(current_volume_str, NULL, 10);
	load_super(current_vol);

	printf("Volume list : \n");
	printf("Nombre de volumes: %d\n",mbr.nb_vols);

	for(i=0; i<mbr.nb_vols; i++) {
		printf("Vol N°%d: <block total : %d> <start at (cylinder:%u, sector:%u)>\n",i,mbr.vols[i].nb_blocs,mbr.vols[i].premier_cylindre,mbr.vols[i].premier_secteur);

		if(i == current_vol) {
			j= super.nbBlocsLibres+1;
			printf("<CURRENT Vol N°:%d> <name: %s> <serial: %d> <free block: %u (%u %%)>\n", i,super.name, super.serial,j,j*100/mbr.vols[i].nb_blocs);
		}
	}

	return EXIT_SUCCESS;
}
