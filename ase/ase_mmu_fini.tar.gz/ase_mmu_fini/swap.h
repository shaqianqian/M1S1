int init_swap(void);
int store_to_swap(int vpage, int ppage);
int fetch_from_swap(int vpage, int ppage);

