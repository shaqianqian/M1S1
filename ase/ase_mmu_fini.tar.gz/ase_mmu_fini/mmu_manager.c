#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "mi.h"
#include "hardware.h"
#include "swap.h"
#include "mmu_manager.h"
unsigned int ppage_current = 1;

static void empty_it() {
  return;
}
void initialize() {

	int i;
	/* init hardware */
	if (init_hardware("hardware.ini") == 0) {
	        fprintf(stderr, "Error in hardware initialization\n");
	        exit(EXIT_FAILURE);
	}
    	/* Interrupt handlers */
    	for (i = 0; i < 16; i++)
        	IRQVECTOR[i] = empty_it;
	IRQVECTOR[MMU_IRQ] = mmu_handler;
}

void mmu_handler() {
	union tlb_entry_u tlbent;
	unsigned int vpage_to_swap = pm_mapping[ppage_current];
	//calculate form ppage to vpage
	unsigned int vpage;
	unsigned int ppage;
	vpage = _in(MMU_FAULT_ADDR);
	assert(vpage >=(unsigned int) virtual_memory && vpage < (unsigned int) virtual_memory + VM_SIZE);
	vpage = vpage>>12&0xfff;
	if((ppage = vm_mapping[vpage]) != -1) {		
		tlbent.tlb_s.ppage = ppage;
		tlbent.tlb_s.vpage = vpage;
		tlbent.tlb_s.exec = 1;
		tlbent.tlb_s.read = 1;
		tlbent.tlb_s.write = 1;
		tlbent.tlb_s.used = 1;
		_out(TLB_ADD_ENTRY, tlbent.i);
	}
	else {
		store_to_swap(vpage_to_swap, ppage_current);
		tlbent.tlb_s.vpage = vpage;
		tlbent.tlb_s.ppage = ppage;
		_out(TLB_DEL_ENTRY, tlbent.i);
		fetch_from_swap(vpage, ppage_current);
		tlbent.tlb_s.ppage = ppage_current;
		tlbent.tlb_s.vpage = vpage;
		tlbent.tlb_s.exec = 1;
		tlbent.tlb_s.read = 1;
		tlbent.tlb_s.write = 1;
		tlbent.tlb_s.used = 1;
		_out(TLB_ADD_ENTRY, tlbent.i);
		vm_mapping[pm_mapping[ppage_current]] = -1;
		pm_mapping[ppage_current] = vpage;
		vm_mapping[vpage] = ppage_current;
	}	
}


int main(int argc, char **argv) {
  initialize();

  init_swap(); 

//initialize to -1
  for(int i = 1; i < PM_PAGES; i++) {
		pm_mapping[i] = -1;
	}

  for(int i = 0; i < VM_PAGES; i++) {
		vm_mapping[i] = -1;
  }

  _mask(0x1001);

  user_process();

  return 0;
}
