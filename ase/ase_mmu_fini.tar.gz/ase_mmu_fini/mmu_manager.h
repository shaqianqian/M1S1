
extern void user_process();

/* Page virtuelle vers page physique */
int vm_mapping[VM_PAGES];
/* Page physique vers page virtuelle */
int pm_mapping[PM_PAGES];

void mmu_handler();

