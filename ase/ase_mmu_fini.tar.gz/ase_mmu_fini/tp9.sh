make
./mi
make clean

