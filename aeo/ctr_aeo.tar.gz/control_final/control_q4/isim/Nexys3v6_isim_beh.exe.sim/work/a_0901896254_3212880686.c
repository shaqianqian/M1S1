/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x9ca8bed6 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/parallels/Desktop/control_final/control_q4/Nexys3v6.vhd";



static void work_a_0901896254_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(202, ng0);

LAB3:    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 9832);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 9720);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0901896254_3212880686_p_1(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    char *t16;
    char *t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    unsigned char t21;
    unsigned char t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned char t29;
    char *t30;
    char *t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    unsigned char t35;
    unsigned char t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    char *t44;
    char *t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    unsigned char t49;
    unsigned char t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;

LAB0:    xsi_set_current_line(217, ng0);
    t2 = (t0 + 5032U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t16 = (t0 + 5032U);
    t17 = *((char **)t16);
    t18 = *((unsigned char *)t17);
    t19 = (t18 == (unsigned char)2);
    if (t19 == 1)
        goto LAB10;

LAB11:    t15 = (unsigned char)0;

LAB12:    if (t15 != 0)
        goto LAB8;

LAB9:    t30 = (t0 + 5032U);
    t31 = *((char **)t30);
    t32 = *((unsigned char *)t31);
    t33 = (t32 == (unsigned char)3);
    if (t33 == 1)
        goto LAB15;

LAB16:    t29 = (unsigned char)0;

LAB17:    if (t29 != 0)
        goto LAB13;

LAB14:    t44 = (t0 + 5032U);
    t45 = *((char **)t44);
    t46 = *((unsigned char *)t45);
    t47 = (t46 == (unsigned char)2);
    if (t47 == 1)
        goto LAB20;

LAB21:    t43 = (unsigned char)0;

LAB22:    if (t43 != 0)
        goto LAB18;

LAB19:
LAB23:    t57 = (t0 + 16391);
    t59 = (t0 + 9896);
    t60 = (t59 + 56U);
    t61 = *((char **)t60);
    t62 = (t61 + 56U);
    t63 = *((char **)t62);
    memcpy(t63, t57, 2U);
    xsi_driver_first_trans_fast(t59);

LAB2:    t64 = (t0 + 9736);
    *((int *)t64) = 1;

LAB1:    return;
LAB3:    t2 = (t0 + 16383);
    t10 = (t0 + 9896);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast(t10);
    goto LAB2;

LAB5:    t2 = (t0 + 4712U);
    t6 = *((char **)t2);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    t1 = t8;
    goto LAB7;

LAB8:    t16 = (t0 + 16385);
    t24 = (t0 + 9896);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t16, 2U);
    xsi_driver_first_trans_fast(t24);
    goto LAB2;

LAB10:    t16 = (t0 + 4712U);
    t20 = *((char **)t16);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)3);
    t15 = t22;
    goto LAB12;

LAB13:    t30 = (t0 + 16387);
    t38 = (t0 + 9896);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t30, 2U);
    xsi_driver_first_trans_fast(t38);
    goto LAB2;

LAB15:    t30 = (t0 + 4712U);
    t34 = *((char **)t30);
    t35 = *((unsigned char *)t34);
    t36 = (t35 == (unsigned char)2);
    t29 = t36;
    goto LAB17;

LAB18:    t44 = (t0 + 16389);
    t52 = (t0 + 9896);
    t53 = (t52 + 56U);
    t54 = *((char **)t53);
    t55 = (t54 + 56U);
    t56 = *((char **)t55);
    memcpy(t56, t44, 2U);
    xsi_driver_first_trans_fast(t52);
    goto LAB2;

LAB20:    t44 = (t0 + 4712U);
    t48 = *((char **)t44);
    t49 = *((unsigned char *)t48);
    t50 = (t49 == (unsigned char)3);
    t43 = t50;
    goto LAB22;

LAB24:    goto LAB2;

}

static void work_a_0901896254_3212880686_p_2(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    static char *nl0[] = {&&LAB9, &&LAB10};

LAB0:    xsi_set_current_line(332, ng0);
    t2 = (t0 + 3072U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 9752);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(334, ng0);
    t4 = (t0 + 6952U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (char *)((nl0) + t9);
    goto **((char **)t4);

LAB5:    t4 = (t0 + 3112U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    goto LAB3;

LAB9:    xsi_set_current_line(337, ng0);
    t10 = (t0 + 9960);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t10);
    xsi_set_current_line(338, ng0);
    t2 = (t0 + 5032U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB12;

LAB14:    xsi_set_current_line(341, ng0);
    t2 = (t0 + 10024);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);

LAB13:    goto LAB8;

LAB10:    xsi_set_current_line(345, ng0);
    t2 = (t0 + 9960);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(346, ng0);
    t2 = (t0 + 5032U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB15;

LAB17:    xsi_set_current_line(349, ng0);
    t2 = (t0 + 10024);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);

LAB16:    goto LAB8;

LAB11:    xsi_set_current_line(352, ng0);
    t2 = (t0 + 9960);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(353, ng0);
    t2 = (t0 + 10024);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB12:    xsi_set_current_line(339, ng0);
    t2 = (t0 + 10024);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB13;

LAB15:    xsi_set_current_line(347, ng0);
    t2 = (t0 + 10024);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

}


extern void work_a_0901896254_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0901896254_3212880686_p_0,(void *)work_a_0901896254_3212880686_p_1,(void *)work_a_0901896254_3212880686_p_2};
	xsi_register_didat("work_a_0901896254_3212880686", "isim/Nexys3v6_isim_beh.exe.sim/work/a_0901896254_3212880686.didat");
	xsi_register_executes(pe);
}
