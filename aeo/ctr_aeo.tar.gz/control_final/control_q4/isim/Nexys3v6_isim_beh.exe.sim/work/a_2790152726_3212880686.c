/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x9ca8bed6 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/parallels/Desktop/control_final/control_q4/IP_switch.vhd";
extern char *IEEE_P_2592010699;



static void work_a_2790152726_3212880686_p_0(char *t0)
{
    char t16[16];
    char t18[16];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t17;
    char *t19;
    char *t20;
    int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;

LAB0:    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (10 - 10);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4806);
    t8 = 1;
    if (11U == 11U)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    if (t8 != 0)
        goto LAB3;

LAB4:
LAB11:    t28 = xsi_get_transient_memory(32U);
    memset(t28, 0, 32U);
    t29 = t28;
    memset(t29, (unsigned char)4, 32U);
    t30 = (t0 + 3024);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memcpy(t34, t28, 32U);
    xsi_driver_first_trans_fast_port(t30);

LAB2:    t35 = (t0 + 2944);
    *((int *)t35) = 1;

LAB1:    return;
LAB3:    t12 = (t0 + 4817);
    t14 = (t0 + 1032U);
    t15 = *((char **)t14);
    t17 = ((IEEE_P_2592010699) + 4000);
    t19 = (t18 + 0U);
    t20 = (t19 + 0U);
    *((int *)t20) = 0;
    t20 = (t19 + 4U);
    *((int *)t20) = 23;
    t20 = (t19 + 8U);
    *((int *)t20) = 1;
    t21 = (23 - 0);
    t22 = (t21 * 1);
    t22 = (t22 + 1);
    t20 = (t19 + 12U);
    *((unsigned int *)t20) = t22;
    t20 = (t0 + 4720U);
    t14 = xsi_base_array_concat(t14, t16, t17, (char)97, t12, t18, (char)97, t15, t20, (char)101);
    t23 = (t0 + 3024);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t14, 32U);
    xsi_driver_first_trans_fast_port(t23);
    goto LAB2;

LAB5:    t9 = 0;

LAB8:    if (t9 < 11U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB6;

LAB10:    t9 = (t9 + 1);
    goto LAB8;

LAB12:    goto LAB2;

}


extern void work_a_2790152726_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2790152726_3212880686_p_0};
	xsi_register_didat("work_a_2790152726_3212880686", "isim/Nexys3v6_isim_beh.exe.sim/work/a_2790152726_3212880686.didat");
	xsi_register_executes(pe);
}
