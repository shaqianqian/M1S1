The following files were generated for 'multiply' in directory 
C:\Users\jld\TP_AEV_2015\lastzip\nexys3V6.12.4\ipcore_dir\

multiply.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

multiply.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

multiply.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

multiply.sym:
   Please see the core data sheet.

multiply.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

multiply.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

multiply.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

multiply.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

multiply.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

multiply.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

multiply_readme.txt:
   Text file indicating the files generated and how they are used.

multiply_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

multiply_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

