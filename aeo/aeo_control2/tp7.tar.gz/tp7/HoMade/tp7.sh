cd ..
djtgcfg -d Nexys3 prog -i 0 -f Nexys3v6.bit
cat HoMade/qestion3.hmd > /dev/ttyUSB0
